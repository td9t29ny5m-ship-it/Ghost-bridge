tp @s ~ -350 ~
kill @s
