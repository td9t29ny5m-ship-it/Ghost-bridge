scoreboard players add @s pl_ammo 60
