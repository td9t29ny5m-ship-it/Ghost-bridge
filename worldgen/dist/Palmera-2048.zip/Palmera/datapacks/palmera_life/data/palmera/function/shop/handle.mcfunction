execute if score @s pl_shop matches 99 run function palmera:shop/menu_guns
execute if score @s pl_shop matches 98 run function palmera:shop/menu_cars
execute if score @s pl_shop matches 1 run function palmera:shop/buy {price:500,item:"pistol",label:"Pistol"}
execute if score @s pl_shop matches 2 run function palmera:shop/buy {price:2500,item:"smg",label:"SMG"}
execute if score @s pl_shop matches 3 run function palmera:shop/buy {price:3500,item:"shotgun",label:"Pump Shotgun"}
execute if score @s pl_shop matches 4 run function palmera:shop/buy {price:7500,item:"rifle",label:"Assault Rifle"}
execute if score @s pl_shop matches 5 run function palmera:shop/buy {price:25000,item:"rocket",label:"Rocket Launcher"}
execute if score @s pl_shop matches 6 run function palmera:shop/buy {price:150,item:"ammo",label:"Ammo x60"}
execute if score @s pl_shop matches 7 run function palmera:shop/buy {price:600,item:"grenade",label:"Grenades x4"}
execute if score @s pl_shop matches 8 run function palmera:shop/buy {price:1500,item:"armor",label:"Body Armor"}
execute if score @s pl_shop matches 9 run function palmera:shop/buy {price:300,item:"medkit",label:"Medkits x3"}
execute if score @s pl_shop matches 10 run function palmera:shop/buy {price:100,item:"bat",label:"Baseball Bat"}
execute if score @s pl_shop matches 20 run function palmera:shop/buy {price:4000,item:"car_sedan",label:"Sedan"}
execute if score @s pl_shop matches 21 run function palmera:shop/buy {price:15000,item:"car_sports",label:"Sports Car"}
scoreboard players set @s pl_shop 0
