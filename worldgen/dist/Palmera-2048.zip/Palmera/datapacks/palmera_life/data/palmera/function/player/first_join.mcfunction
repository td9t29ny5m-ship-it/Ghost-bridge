scoreboard players set @s pl_joined 1
scoreboard players set @s pl_cash 2500
scoreboard players set @s pl_ammo 60
scoreboard players set @s pl_wanted 0
scoreboard players set @s pl_car 0
give @s carrot_on_a_stick[custom_data={phone:1b},custom_model_data=1010,custom_name='{"text": "Phone", "color": "light_purple", "italic": false, "bold": false}',unbreakable={show_in_tooltip:false},lore=['{"text":"Right-click to open","color":"gray","italic":false}']] 1
give @s carrot_on_a_stick[custom_data={gun:"pistol"},custom_model_data=1001,custom_name='{"text": "Pistol", "color": "gold", "italic": false, "bold": false}',unbreakable={show_in_tooltip:false},lore=['{"text":"Right-click to fire","color":"gray","italic":false}']] 1
title @s times 10 70 20
title @s title {"text":"PALMERA","color":"light_purple","bold":true}
title @s subtitle {"text":"Welcome to the sunshine state","color":"aqua"}
tellraw @s ["",{"text":"\nWelcome to Palmera! ","color":"light_purple","bold":true},{"text":"You have $2,500, a pistol and a phone.\n","color":"white"},{"text":"Right-click the Phone to buy guns and cars, and to take jobs. Hurting civilians brings the cops.\n","color":"gray"},{"text":"[ Open Phone ]","color":"gold","clickEvent":{"action":"run_command","value":"/trigger pl_menu set 1"}}]
