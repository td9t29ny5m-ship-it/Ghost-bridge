give @s iron_chestplate[custom_name='{"text": "Body Armor", "color": "gray", "italic": false, "bold": false}',enchantments={levels:{"minecraft:protection":3}}] 1
