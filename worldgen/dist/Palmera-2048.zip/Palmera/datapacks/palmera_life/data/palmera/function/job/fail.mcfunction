tellraw @a[tag=pl_jobowner] {"text":"Job failed.","color":"red"}
execute as @e[tag=job_enemy] at @s run tp @s ~ -350 ~
kill @e[tag=job_enemy]
function palmera:job/reset
