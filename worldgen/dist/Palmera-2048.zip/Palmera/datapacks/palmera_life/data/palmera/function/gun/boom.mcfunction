summon creeper ~ ~ ~ {Fuse:0s,ignited:1b,ExplosionRadius:4b,Silent:1b,Invulnerable:1b,Tags:["pl_boom"]}
particle minecraft:explosion_emitter ~ ~ ~
