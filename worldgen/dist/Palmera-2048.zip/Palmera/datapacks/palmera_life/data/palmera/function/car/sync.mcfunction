scoreboard players operation #cid pl_g = @s pl_car
execute as @e[type=block_display,tag=car_part,distance=..8] if score @s pl_car = #cid pl_g run function palmera:car/part
