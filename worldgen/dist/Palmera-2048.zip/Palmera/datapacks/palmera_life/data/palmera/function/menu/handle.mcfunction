execute if score @s pl_menu matches 1 run function palmera:menu/open
execute if score @s pl_menu matches 2 run function palmera:menu/stats
scoreboard players set @s pl_menu 0
