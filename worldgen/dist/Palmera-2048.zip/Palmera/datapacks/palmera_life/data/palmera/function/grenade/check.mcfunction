tag @s add pl_gchk
execute if data entity @s Item.components."minecraft:custom_data".grenade run tag @s add pl_gren
