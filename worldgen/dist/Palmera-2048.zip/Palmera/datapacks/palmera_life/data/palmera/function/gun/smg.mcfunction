execute unless score @s pl_ammo matches 1.. run return run function palmera:gun/empty
scoreboard players remove @s pl_ammo 1
scoreboard players set @s pl_cd 0
playsound minecraft:entity.firework_rocket.blast player @a ~ ~ ~ 1.5 2.0
function palmera:gun/heat
tag @s add pl_shooter
scoreboard players set #steps pl_tmp 60
scoreboard players set #hit pl_tmp 0
execute rotated ~0 ~0 anchored eyes positioned ^ ^ ^0.6 anchored feet run function palmera:gun/ray_smg
tag @s remove pl_shooter
