execute as @a[scores={pl_wanted=1..},gamemode=!spectator] at @s run function palmera:police/spawn_for
schedule function palmera:police/cycle 100t replace
