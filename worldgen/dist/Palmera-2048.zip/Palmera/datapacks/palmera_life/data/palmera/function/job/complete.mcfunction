scoreboard players operation @a[tag=pl_jobowner] pl_cash += #reward pl_g
scoreboard players add @a[tag=pl_jobowner] pl_jobsdone 1
execute as @a[tag=pl_jobowner] at @s run playsound minecraft:ui.toast.challenge_complete player @s
title @a[tag=pl_jobowner] title {"text":"JOB COMPLETE","color":"gold","bold":true}
title @a[tag=pl_jobowner] subtitle [{"text":"+$","color":"green"},{"score":{"name":"#reward","objective":"pl_g"},"color":"green"}]
function palmera:job/reset
