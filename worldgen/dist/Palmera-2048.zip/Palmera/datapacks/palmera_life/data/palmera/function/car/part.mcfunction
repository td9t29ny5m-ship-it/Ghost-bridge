tp @s ~ ~ ~ ~ 0
tag @s add car_seen
