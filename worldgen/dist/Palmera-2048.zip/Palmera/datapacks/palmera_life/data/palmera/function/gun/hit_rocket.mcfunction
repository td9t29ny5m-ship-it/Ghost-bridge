function palmera:gun/boom
particle minecraft:damage_indicator ~ ~ ~ 0.2 0.2 0.2 0.1 3
playsound minecraft:entity.arrow.hit_player player @s
