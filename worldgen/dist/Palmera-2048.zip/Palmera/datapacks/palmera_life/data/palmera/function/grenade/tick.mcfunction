execute as @e[type=marker,tag=pl_gpos] at @s unless entity @e[type=snowball,tag=pl_gren,distance=..4] run function palmera:gun/boom
kill @e[type=marker,tag=pl_gpos]
execute as @e[type=snowball,tag=!pl_gchk] run function palmera:grenade/check
execute as @e[type=snowball,tag=pl_gren] at @s run summon marker ~ ~ ~ {Tags:["pl_gpos"]}
execute as @e[type=snowball,tag=pl_gren] at @s run particle minecraft:smoke ~ ~ ~ 0 0 0 0 1
