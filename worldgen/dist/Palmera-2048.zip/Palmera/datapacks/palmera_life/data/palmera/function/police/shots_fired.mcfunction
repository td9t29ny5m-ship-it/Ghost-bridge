scoreboard players set @s pl_wanted 1
scoreboard players set @s pl_wcd 400
title @s actionbar {"text":"Shots fired! The police are on the way.","color":"red"}
