execute if score @s pl_job matches 99 run function palmera:job/list
execute if score @s pl_job matches 50 if entity @s[tag=pl_jobowner] run function palmera:job/fail
execute if score @s pl_job matches 1 run function palmera:job/start_1
execute if score @s pl_job matches 2 run function palmera:job/start_2
execute if score @s pl_job matches 3 run function palmera:job/start_3
execute if score @s pl_job matches 4 run function palmera:job/start_4
execute if score @s pl_job matches 5 run function palmera:job/start_5
execute if score @s pl_job matches 6 run function palmera:job/start_6
scoreboard players set @s pl_job 0
