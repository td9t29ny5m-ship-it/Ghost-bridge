function palmera:car/buy_sports
