execute if score #job pl_g matches 1.. run return run tellraw @s {"text":"A job is already running. Finish or cancel it first.","color":"red"}
scoreboard players set #job pl_g 1
scoreboard players set #jobsp pl_g 0
tag @s add pl_jobowner
give @s compass[lodestone_tracker={target:{pos:[I;1773,66,671],dimension:"minecraft:overworld"},tracked:false},custom_data={jobgps:1b},custom_name='{"text": "Job GPS: Beach Brawl", "color": "red", "italic": false, "bold": false}'] 1
title @s times 10 60 20
title @s title {"text": "Beach Brawl", "color": "red", "bold": true}
title @s subtitle {"text": "Coral Strand", "color": "gray"}
tellraw @s ["", {"text": "Some thugs are shaking down beach vendors. Run them off. ", "color": "white"}, {"text": "Follow the Job GPS to 1773 66 671.", "color": "gray"}]
