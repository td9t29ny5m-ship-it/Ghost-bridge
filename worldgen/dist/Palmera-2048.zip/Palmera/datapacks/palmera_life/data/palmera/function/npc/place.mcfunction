execute if entity @a[distance=..12] run return 0
execute unless entity @s[y=62,dy=5] run return 0
execute unless block ~ ~-1 ~ #palmera:walkable run return 0
execute unless block ~ ~ ~ #palmera:passable run return 0
execute store result score #r pl_tmp run random value 0..39
function palmera:npc/variant
