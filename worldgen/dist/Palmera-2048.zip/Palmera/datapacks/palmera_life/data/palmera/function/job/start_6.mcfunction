execute if score #job pl_g matches 1.. run return run tellraw @s {"text":"A job is already running. Finish or cancel it first.","color":"red"}
scoreboard players set #job pl_g 6
scoreboard players set #jobsp pl_g 0
tag @s add pl_jobowner
give @s compass[lodestone_tracker={target:{pos:[I;1664,65,956],dimension:"minecraft:overworld"},tracked:false},custom_data={jobgps:1b},custom_name='{"text": "Job GPS: Isle Heist", "color": "red", "italic": false, "bold": false}'] 1
title @s times 10 60 20
title @s title {"text": "Isle Heist", "color": "red", "bold": true}
title @s subtitle {"text": "Millionaire Isles", "color": "gray"}
tellraw @s ["", {"text": "The Kingpin is hiding out in a mansion. Get past his guards. ", "color": "white"}, {"text": "Follow the Job GPS to 1664 65 956.", "color": "gray"}]
