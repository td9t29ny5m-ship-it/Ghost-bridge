particle minecraft:smoke ~ ~ ~ 0.05 0.05 0.05 0.01 4
