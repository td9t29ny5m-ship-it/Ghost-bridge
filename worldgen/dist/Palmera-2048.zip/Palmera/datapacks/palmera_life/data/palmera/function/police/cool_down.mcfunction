scoreboard players remove @s pl_wanted 1
scoreboard players set @s pl_wcd 600
execute if score @s pl_wanted matches 0 run tellraw @s {"text":"You lost the cops.","color":"green"}
execute unless entity @a[scores={pl_wanted=1..}] run function palmera:police/clear
