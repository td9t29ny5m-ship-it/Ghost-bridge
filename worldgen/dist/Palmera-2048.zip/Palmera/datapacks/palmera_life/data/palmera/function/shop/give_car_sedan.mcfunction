function palmera:car/buy_sedan
