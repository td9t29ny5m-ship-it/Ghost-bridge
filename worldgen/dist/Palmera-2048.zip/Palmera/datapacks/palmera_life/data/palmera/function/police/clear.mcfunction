execute as @e[tag=cop] at @s run tp @s ~ -350 ~
kill @e[tag=cop]
