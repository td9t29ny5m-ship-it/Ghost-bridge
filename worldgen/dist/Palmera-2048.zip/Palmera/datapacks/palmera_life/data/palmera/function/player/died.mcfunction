scoreboard players reset @s pl_death
scoreboard players set @s pl_wanted 0
scoreboard players remove @s pl_cash 500
execute if score @s pl_cash matches ..-1 run scoreboard players set @s pl_cash 0
title @s times 5 60 20
title @s title {"text":"YOU DIED","color":"dark_red","bold":true}
title @s subtitle {"text":"Hospital bill: $500","color":"gray"}
execute if entity @s[tag=pl_jobowner] run function palmera:job/fail
execute unless entity @a[scores={pl_wanted=1..}] run function palmera:police/clear
