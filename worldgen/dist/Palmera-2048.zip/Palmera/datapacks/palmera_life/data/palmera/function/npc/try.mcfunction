summon marker ~ ~ ~ {Tags:["pl_pspot"]}
spreadplayers ~ ~ 2 34 under 72 false @e[type=marker,tag=pl_pspot]
execute as @e[type=marker,tag=pl_pspot] at @s run function palmera:npc/place
kill @e[type=marker,tag=pl_pspot]
