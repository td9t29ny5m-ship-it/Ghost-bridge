clear @a[tag=pl_jobowner] compass[custom_data~{jobgps:1b}]
tag @a remove pl_jobowner
scoreboard players set #job pl_g 0
scoreboard players set #jobsp pl_g 0
