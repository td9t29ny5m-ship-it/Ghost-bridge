give @s snowball[custom_data={grenade:1b},custom_model_data=1201,custom_name='{"text": "Grenade", "color": "red", "italic": false, "bold": false}'] 4
