scoreboard objectives add pl_use minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add pl_cash dummy
scoreboard objectives add pl_ammo dummy
scoreboard objectives add pl_wanted dummy
scoreboard objectives add pl_wcd dummy
scoreboard objectives add pl_cd dummy
scoreboard objectives add pl_tmp dummy
scoreboard objectives add pl_g dummy
scoreboard objectives add pl_const dummy
scoreboard objectives add pl_joined dummy
scoreboard objectives add pl_death deathCount
scoreboard objectives add pl_car dummy
scoreboard objectives add pl_kped minecraft.killed:minecraft.villager
scoreboard objectives add pl_kcop1 minecraft.killed:minecraft.skeleton
scoreboard objectives add pl_kcop2 minecraft.killed:minecraft.wither_skeleton
scoreboard objectives add pl_kcop3 minecraft.killed:minecraft.phantom
scoreboard objectives add pl_shop trigger
scoreboard objectives add pl_job trigger
scoreboard objectives add pl_menu trigger
scoreboard objectives add pl_jobsdone dummy
scoreboard objectives add pl_crimes dummy
scoreboard players set #2 pl_const 2
scoreboard players set #50 pl_const 50
execute unless score #job pl_g matches 0.. run scoreboard players set #job pl_g 0
execute unless score #jobsp pl_g matches 0.. run scoreboard players set #jobsp pl_g 0
schedule function palmera:npc/cycle 40t replace
schedule function palmera:police/cycle 100t replace
tellraw @a {"text":"[Palmera Life] loaded. Right-click your Phone or type /trigger pl_menu","color":"light_purple"}
