scoreboard players reset @s pl_kped
scoreboard players add @s pl_crimes 1
function palmera:police/add_star
