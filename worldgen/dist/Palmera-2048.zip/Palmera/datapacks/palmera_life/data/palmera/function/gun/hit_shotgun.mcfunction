damage @e[type=!#palmera:not_target,tag=!pl_shooter,tag=!car,distance=..1.6,sort=nearest,limit=1] 4 palmera:bullet by @s
particle minecraft:damage_indicator ~ ~ ~ 0.2 0.2 0.2 0.1 3
playsound minecraft:entity.arrow.hit_player player @s
