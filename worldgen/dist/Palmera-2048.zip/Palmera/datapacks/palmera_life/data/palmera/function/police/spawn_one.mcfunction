summon marker ~ ~ ~ {Tags:["pl_cspot"]}
spreadplayers ~ ~ 2 26 under 90 false @e[type=marker,tag=pl_cspot]
execute as @e[type=marker,tag=pl_cspot] at @s run function palmera:police/place
kill @e[type=marker,tag=pl_cspot]
