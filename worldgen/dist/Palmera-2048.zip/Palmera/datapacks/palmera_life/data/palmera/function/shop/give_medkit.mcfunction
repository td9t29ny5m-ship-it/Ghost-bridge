give @s golden_apple[custom_name='{"text": "Medkit", "color": "green", "italic": false, "bold": false}'] 3
