function palmera:gun/boom
