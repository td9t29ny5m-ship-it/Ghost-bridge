execute store result score @s pl_tmp run clear @s emerald[custom_data~{cash:1b}]
execute if score @s pl_tmp matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 1.4
scoreboard players operation @s pl_tmp *= #50 pl_const
scoreboard players operation @s pl_cash += @s pl_tmp
