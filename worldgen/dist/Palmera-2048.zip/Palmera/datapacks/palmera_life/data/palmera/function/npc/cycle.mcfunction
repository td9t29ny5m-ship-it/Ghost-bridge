execute as @a[gamemode=!spectator] at @s run function palmera:npc/around
execute as @e[type=villager,tag=ped] at @s unless entity @a[distance=..80] run function palmera:npc/despawn
schedule function palmera:npc/cycle 40t replace
