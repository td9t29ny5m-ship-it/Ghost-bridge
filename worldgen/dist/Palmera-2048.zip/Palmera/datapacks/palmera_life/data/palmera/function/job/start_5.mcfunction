execute if score #job pl_g matches 1.. run return run tellraw @s {"text":"A job is already running. Finish or cancel it first.","color":"red"}
scoreboard players set #job pl_g 5
scoreboard players set #jobsp pl_g 0
tag @s add pl_jobowner
give @s compass[lodestone_tracker={target:{pos:[I;1392,65,225],dimension:"minecraft:overworld"},tracked:false},custom_data={jobgps:1b},custom_name='{"text": "Job GPS: Launch Day", "color": "red", "italic": false, "bold": false}'] 1
title @s times 10 60 20
title @s title {"text": "Launch Day", "color": "red", "bold": true}
title @s subtitle {"text": "Spaceport", "color": "gray"}
tellraw @s ["", {"text": "Saboteurs want to wreck the launch. Stop them and their getaway truck. ", "color": "white"}, {"text": "Follow the Job GPS to 1392 65 225.", "color": "gray"}]
