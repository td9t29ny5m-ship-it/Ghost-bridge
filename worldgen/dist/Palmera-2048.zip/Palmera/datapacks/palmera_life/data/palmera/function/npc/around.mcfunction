execute store result score #c pl_tmp if entity @e[type=villager,tag=ped,distance=..48]
execute if score #c pl_tmp matches ..13 run function palmera:npc/try
execute if score #c pl_tmp matches ..8 run function palmera:npc/try
