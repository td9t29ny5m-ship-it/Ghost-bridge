scoreboard players operation #lvl pl_g = @s pl_wanted
execute store result score #c pl_tmp if entity @e[tag=cop,distance=..56]
scoreboard players operation #t pl_tmp = @s pl_wanted
scoreboard players operation #t pl_tmp *= #2 pl_const
scoreboard players add #t pl_tmp 1
execute if score #c pl_tmp < #t pl_tmp run function palmera:police/spawn_one
execute if score #c pl_tmp < #t pl_tmp run function palmera:police/spawn_one
