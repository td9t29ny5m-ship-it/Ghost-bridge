scoreboard players operation #cid pl_g = @s pl_car
execute if score #cid pl_g matches 1.. as @e[tag=car_any] if score @s pl_car = #cid pl_g at @s run tp @s ~ -350 ~
execute if score #cid pl_g matches 1.. as @e[tag=car_any] if score @s pl_car = #cid pl_g run kill @s
scoreboard players add #nextcar pl_g 1
scoreboard players operation @s pl_car = #nextcar pl_g
execute store result score #r pl_tmp run random value 0..9
execute rotated ~ 0 positioned ^ ^ ^4 run function palmera:car/sports_pick
scoreboard players operation @e[tag=car_new] pl_car = #nextcar pl_g
tag @e[tag=car_new] remove car_new
tellraw @s {"text":"Your car is parked in front of you. Right-click it to get in.","color":"aqua"}
