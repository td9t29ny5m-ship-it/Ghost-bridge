playsound minecraft:block.dispenser.fail player @s ~ ~ ~ 1 1.8
title @s actionbar {"text":"Out of ammo! Buy more from Sunshine Arms.","color":"red"}
scoreboard players set @s pl_cd 10
