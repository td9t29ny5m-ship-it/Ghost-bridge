execute if score #job pl_g matches 1 if score #jobsp pl_g matches 0 positioned 1773 66 671 if entity @a[tag=pl_jobowner,distance=..64] run function palmera:job/spawn_1
execute if score #job pl_g matches 2 if score #jobsp pl_g matches 0 positioned 1515 65 1433 if entity @a[tag=pl_jobowner,distance=..64] run function palmera:job/spawn_2
execute if score #job pl_g matches 3 if score #jobsp pl_g matches 0 positioned 593 65 1464 if entity @a[tag=pl_jobowner,distance=..64] run function palmera:job/spawn_3
execute if score #job pl_g matches 4 if score #jobsp pl_g matches 0 positioned 1392 65 555 if entity @a[tag=pl_jobowner,distance=..64] run function palmera:job/spawn_4
execute if score #job pl_g matches 5 if score #jobsp pl_g matches 0 positioned 1392 65 225 if entity @a[tag=pl_jobowner,distance=..64] run function palmera:job/spawn_5
execute if score #job pl_g matches 6 if score #jobsp pl_g matches 0 positioned 1664 65 956 if entity @a[tag=pl_jobowner,distance=..64] run function palmera:job/spawn_6
execute if score #jobsp pl_g matches 1 unless entity @e[tag=job_enemy] run function palmera:job/complete
