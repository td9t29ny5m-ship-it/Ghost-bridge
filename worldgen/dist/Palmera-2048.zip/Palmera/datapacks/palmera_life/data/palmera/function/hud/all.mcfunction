scoreboard players set #hud pl_g 0
execute as @a run function palmera:hud/show
