particle minecraft:crit ~ ~ ~ 0 0 0 0 1
execute if block ~ ~ ~ #palmera:glass run setblock ~ ~ ~ air destroy
execute positioned ~-0.5 ~-0.5 ~-0.5 if entity @e[dx=0,dy=0,dz=0,type=!#palmera:not_target,tag=!pl_shooter,tag=!car] positioned ~0.5 ~0.5 ~0.5 run return run function palmera:gun/hit_smg
execute unless block ~ ~ ~ #palmera:passable run return run function palmera:gun/stop_smg
scoreboard players remove #steps pl_tmp 1
execute if score #steps pl_tmp matches 1.. positioned ^ ^ ^0.5 run function palmera:gun/ray_smg
