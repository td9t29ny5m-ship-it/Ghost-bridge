execute if score #job pl_g matches 1.. run return run tellraw @s {"text":"A job is already running. Finish or cancel it first.","color":"red"}
scoreboard players set #job pl_g 3
scoreboard players set #jobsp pl_g 0
tag @s add pl_jobowner
give @s compass[lodestone_tracker={target:{pos:[I;593,65,1464],dimension:"minecraft:overworld"},tracked:false},custom_data={jobgps:1b},custom_name='{"text": "Job GPS: Swamp Runners", "color": "red", "italic": false, "bold": false}'] 1
title @s times 10 60 20
title @s title {"text": "Swamp Runners", "color": "red", "bold": true}
title @s subtitle {"text": "Mangrove Point", "color": "gray"}
tellraw @s ["", {"text": "Smugglers are moving product through the swamp. Shut them down. ", "color": "white"}, {"text": "Follow the Job GPS to 593 65 1464.", "color": "gray"}]
