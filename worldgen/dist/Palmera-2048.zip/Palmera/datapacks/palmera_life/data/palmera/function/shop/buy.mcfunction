$execute unless score @s pl_cash matches $(price).. run return run tellraw @s {"text":"Not enough cash for $(label) ($$(price)).","color":"red"}
$scoreboard players remove @s pl_cash $(price)
$function palmera:shop/give_$(item)
playsound minecraft:entity.villager.yes player @s ~ ~ ~ 1 1
$tellraw @s {"text":"Bought $(label) for $$(price).","color":"green"}
