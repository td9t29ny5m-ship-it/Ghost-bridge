execute as @e[type=horse,tag=car] at @s run function palmera:car/sync
kill @e[type=block_display,tag=car_part,tag=!car_seen]
tag @e[type=block_display,tag=car_seen] remove car_seen
