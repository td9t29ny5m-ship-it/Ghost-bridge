scoreboard players add @s pl_wanted 1
execute if score @s pl_wanted matches 6.. run scoreboard players set @s pl_wanted 5
scoreboard players set @s pl_wcd 700
playsound minecraft:block.note_block.bell player @s ~ ~ ~ 1 0.6
