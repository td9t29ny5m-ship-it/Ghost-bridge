execute as @a unless score @s pl_joined matches 1 run function palmera:player/first_join
scoreboard players enable @a pl_shop
scoreboard players enable @a pl_job
scoreboard players enable @a pl_menu
execute as @a[scores={pl_menu=1..}] run function palmera:menu/handle
execute as @a[scores={pl_shop=1..}] run function palmera:shop/handle
execute as @a[scores={pl_job=1..}] run function palmera:job/handle
scoreboard players remove @a[scores={pl_cd=1..}] pl_cd 1
execute as @a[scores={pl_use=1..}] at @s run function palmera:item/use
scoreboard players reset @a pl_use
execute as @a[scores={pl_kped=1..}] run function palmera:police/crime_ped
execute as @a[scores={pl_kcop1=1..}] run function palmera:police/crime_cop
execute as @a[scores={pl_kcop2=1..}] run function palmera:police/crime_cop
execute as @a[scores={pl_kcop3=1..}] run function palmera:police/crime_cop
execute as @a[scores={pl_wanted=1..}] at @s unless entity @e[tag=cop,distance=..28] run scoreboard players remove @s pl_wcd 1
execute as @a[scores={pl_wanted=1..,pl_wcd=..0}] run function palmera:police/cool_down
execute as @a[scores={pl_death=1..}] run function palmera:player/died
execute as @a run function palmera:player/cash_pickup
function palmera:grenade/tick
function palmera:car/tick
execute if score #job pl_g matches 1.. run function palmera:job/tick
scoreboard players add #hud pl_g 1
execute if score #hud pl_g matches 5.. run function palmera:hud/all
