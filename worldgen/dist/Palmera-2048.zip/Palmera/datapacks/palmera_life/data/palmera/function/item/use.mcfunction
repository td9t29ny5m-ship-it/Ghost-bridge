execute if items entity @s weapon.mainhand carrot_on_a_stick[custom_data~{phone:1b}] run return run function palmera:menu/open
execute if score @s pl_cd matches 1.. run return 0
execute if items entity @s weapon.mainhand carrot_on_a_stick[custom_data~{gun:"pistol"}] run return run function palmera:gun/pistol
execute if items entity @s weapon.mainhand carrot_on_a_stick[custom_data~{gun:"smg"}] run return run function palmera:gun/smg
execute if items entity @s weapon.mainhand carrot_on_a_stick[custom_data~{gun:"shotgun"}] run return run function palmera:gun/shotgun
execute if items entity @s weapon.mainhand carrot_on_a_stick[custom_data~{gun:"rifle"}] run return run function palmera:gun/rifle
execute if items entity @s weapon.mainhand carrot_on_a_stick[custom_data~{gun:"rocket"}] run return run function palmera:gun/rocket
