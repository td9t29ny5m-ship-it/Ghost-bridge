execute if score #job pl_g matches 1.. run return run tellraw @s {"text":"A job is already running. Finish or cancel it first.","color":"red"}
scoreboard players set #job pl_g 2
scoreboard players set #jobsp pl_g 0
tag @s add pl_jobowner
give @s compass[lodestone_tracker={target:{pos:[I;1515,65,1433],dimension:"minecraft:overworld"},tracked:false},custom_data={jobgps:1b},custom_name='{"text": "Job GPS: Dockside Shakedown", "color": "red", "italic": false, "bold": false}'] 1
title @s times 10 60 20
title @s title {"text": "Dockside Shakedown", "color": "red", "bold": true}
title @s subtitle {"text": "Port Solano", "color": "gray"}
tellraw @s ["", {"text": "A crew is stealing containers at the port. Take out the Dock Boss. ", "color": "white"}, {"text": "Follow the Job GPS to 1515 65 1433.", "color": "gray"}]
