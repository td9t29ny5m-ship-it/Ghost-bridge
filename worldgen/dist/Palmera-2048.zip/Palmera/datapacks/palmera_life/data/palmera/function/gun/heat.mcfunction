execute if score @s pl_wanted matches 0 if entity @e[type=villager,tag=ped,distance=..16] run function palmera:police/shots_fired
