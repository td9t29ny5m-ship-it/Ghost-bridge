scoreboard players reset @s pl_kcop1
scoreboard players reset @s pl_kcop2
scoreboard players reset @s pl_kcop3
scoreboard players add @s pl_crimes 1
function palmera:police/add_star
